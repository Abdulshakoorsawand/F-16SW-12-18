package shakoor.testbluetoothchat;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AlertDialog;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

public class MainActivity extends ActionBarActivity {

	public static final int MESSAGE_STATE_CHANGE = 1;
	public static final int MESSAGE_READ = 2;
	public static final int MESSAGE_WRITE = 3;
	public static final int MESSAGE_DEVICE_NAME = 4;
	public static final int MESSAGE_TOAST = 6;

	public static final String DEVICE_NAME = "device_name";
	public static final String TOAST = "toast";

	private static final int REQUEST_CONNECT_DEVICE = 1;
	private static final int REQUEST_ENABLE_BT = 2;

	private ListView chatList, conversations;
	private EditText editText;
	private Button sendBtn;
	int side, index;

	private String connectedDeviceName="";
	private String connectedDeviceAddress="";

	private ChatArrayAdapter chatArrayAdapter;
	private EntryArrayAdapter entryArrayAdapter;

	private StringBuffer outStringBuffer;
	private BluetoothAdapter bluetoothAdapter = null;
	private ChatManager chatManager = null;

	private Handler handler = new Handler(new Callback() {

		@Override
		public boolean handleMessage(Message msg) {
			switch (msg.what) {
			case MESSAGE_STATE_CHANGE:
				switch (msg.arg1) {
				case ChatManager.STATE_CONNECTED:{
					setStatus(getString(R.string.title_connected_to,
							connectedDeviceName));
					break;}
				case ChatManager.STATE_CONNECTING:{
					setStatus(R.string.title_connecting);
					break;}
				case ChatManager.STATE_LISTEN:
				case ChatManager.STATE_NONE:{
					setStatus(R.string.title_not_connected);
					break;}
				}
				break;
			case MESSAGE_WRITE:{
				byte[] writeBuf = (byte[]) msg.obj;

				String writeMessage = new String(writeBuf);
				side=1;
				chatArrayAdapter.add(new ChatMessage(side, writeMessage, bluetoothAdapter.getName(), "Me:",
						DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()),
						DateFormat.getDateInstance().format(new Date())));
				break;}
			case MESSAGE_READ:{
				byte[] readBuf = (byte[]) msg.obj;

				String readMessage = new String(readBuf, 0, msg.arg1);
				side=0;
				chatArrayAdapter.add(new ChatMessage(side, readMessage, connectedDeviceName, connectedDeviceName,
						DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()),
						DateFormat.getDateInstance().format(new Date())));
				break;}
			case MESSAGE_DEVICE_NAME:{

				connectedDeviceName = msg.getData().getString(DEVICE_NAME);
				Toast.makeText(getApplicationContext(),
						"Connected to " + connectedDeviceName,
						Toast.LENGTH_SHORT).show();
				break;}
			case MESSAGE_TOAST:{
				Toast.makeText(getApplicationContext(),
						msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
						.show();
				break;}
			}
			return false;
		}
	});

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		editText = (EditText) findViewById(R.id.etMain);
		sendBtn = (Button) findViewById(R.id.btnSend);

		chatList = (ListView) findViewById(R.id.lvMainChat);
		registerForContextMenu(chatList);
		chatArrayAdapter=new ChatArrayAdapter(getApplicationContext(),R.layout.right_bubble_layout);
		chatList.setAdapter(chatArrayAdapter);
		chatList.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);

		chatList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
				MainActivity ma=new MainActivity();
				index=position;
				return false;
			}
		});

		bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

		editText.setOnEditorActionListener(mWriteListener);

		sendBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String message = editText.getText().toString();
				sendMessage(message);
			}
		});

		if (bluetoothAdapter == null) {
			Toast.makeText(this, "Bluetooth is not available",
					Toast.LENGTH_LONG).show();
			finish();
			return;
		}
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case REQUEST_CONNECT_DEVICE:
			if (resultCode == Activity.RESULT_OK) {
				connectDevice(data, true);
			}
			break;
		case REQUEST_ENABLE_BT:
			if (resultCode == Activity.RESULT_OK) {
				setupChat();
			} else {
				Toast.makeText(this, R.string.bt_not_enabled_leaving,
						Toast.LENGTH_SHORT).show();
				finish();
			}
		}
	}

	private void connectDevice(Intent data, boolean secure) {
		String address = data.getExtras().getString(
				DeviceListActivity.DEVICE_ADDRESS);
		BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
		chatManager.connect(device, secure);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.options_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent serverIntent = null;
		switch (item.getItemId()) {
		case R.id.connect_scan:
			serverIntent = new Intent(this, DeviceListActivity.class);
			startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
			return true;

		case R.id.discoverable:
			setVisibleToNearBy();
			return true;
		}
		return false;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
		MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.message_menu,menu);
		super.onCreateContextMenu(menu, v, menuInfo);
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		if(item.getTitle().equals("Delete")){
			final Context context=MainActivity.this;
			AlertDialog.Builder ad=new AlertDialog.Builder(context);
			ad.setTitle("Delete message");
			ad.setMessage("Are you sure you want to delete this message?");
			ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					chatArrayAdapter.remove(chatArrayAdapter.getItem(index));
					chatArrayAdapter.notifyDataSetChanged();
					Toast.makeText(context, "Deleted successfully.", Toast.LENGTH_SHORT).show();
				}
			});
			ad.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				}
			});
			ad.show();
		}
		return super.onContextItemSelected(item);
	}

	private void setVisibleToNearBy() {
		if (bluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {

			Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
			startActivity(discoverableIntent);
		}
	}

	private void sendMessage(String message) {
		if (chatManager.getState() != ChatManager.STATE_CONNECTED) {
			Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
			return;
		}

		if (message.length() > 0) {
			byte[] send = message.getBytes();
			chatManager.write(send);

			outStringBuffer.setLength(0);
			editText.setText(outStringBuffer);
		}
	}

	private TextView.OnEditorActionListener mWriteListener = new TextView.OnEditorActionListener() {
		public boolean onEditorAction(TextView txt, int actionId, KeyEvent event) {
			if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
				String message = txt.getText().toString();
				sendMessage(message);
			}
			return true;
		}
	};

	private final void setStatus(int resId) {
		final ActionBar actionBar = getSupportActionBar();
		actionBar.setSubtitle(resId);
	}

	private final void setStatus(CharSequence subTitle) {
		final ActionBar actionBar = getSupportActionBar();
		actionBar.setSubtitle(subTitle);
	}

	private void setupChat() {
		chatManager = new ChatManager(this, handler);

		outStringBuffer = new StringBuffer("");
	}

	@Override
	public void onStart() {
		super.onStart();

		if (!bluetoothAdapter.isEnabled()) {
			Intent enableIntent = new Intent(
					BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
		} else {
			if (chatManager == null)
				setupChat();
		}
	}

	@Override
	public synchronized void onResume() {
		super.onResume();

		if (chatManager != null) {
			if (chatManager.getState() == ChatManager.STATE_NONE) {
				chatManager.start();
			}
		}
	}

	@Override
	public synchronized void onPause() {
		super.onPause();
	}

	@Override
	public void onStop() {
		super.onStop();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (chatManager != null)
			chatManager.stop();
	}

}
