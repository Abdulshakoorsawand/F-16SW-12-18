package shakoor.testbluetoothchat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class EntryArrayAdapter extends ArrayAdapter<Entry> {
    private TextView contactId, contactName, msg, time;
    private List<Entry> entryList=new ArrayList<>();
    private Context context;

    public EntryArrayAdapter(Context context, int resource) {
        super(context, resource);
        this.context=context;
    }
    @Override
    public void add(Entry entry) {
        entryList.add(entry);
        super.add(entry);
    }
    @Override
    public void remove(Entry entry){
        entryList.remove(entry);
        super.remove(entry);
    }
    public Entry getItem(int index) {return this.entryList.get(index);}

    public View getView(int position, View convertView, ViewGroup parent) {
        Entry entry = getItem(position);
        View row = convertView;
        LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row = inflater.inflate(R.layout.entry_layout, parent, false);
        contactId = (TextView) row.findViewById(R.id.contact_id);
        contactId.setText(entry.contactId);
        contactName=(TextView)row.findViewById(R.id.contact_name);
        contactName.setText(entry.contactName);
        msg=(TextView)row.findViewById(R.id.msg);
        msg.setText(entry.msg);
        time=(TextView) row.findViewById(R.id.time);
        time.setText(entry.time);
        return row;
    }
}
