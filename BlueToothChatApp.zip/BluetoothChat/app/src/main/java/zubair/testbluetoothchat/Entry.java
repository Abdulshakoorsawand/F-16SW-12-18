package zubair.testbluetoothchat;


public class Entry {
    public static String contactId,contactName,msg,time;

    public Entry(String contactId, String contactName, String msg, String time){
        super();
        this.contactId=contactId.charAt(0)+""+contactId.charAt(1);
        this.contactName=contactName;
        this.msg=msg;
        this.time=time;
    }
}
