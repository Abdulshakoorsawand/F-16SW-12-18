package zubair.testbluetoothchat;

public class ChatMessage {
    public int side;
    public String message, id, time, date, deviceName;
    int count;

    public ChatMessage(int side, String message, String id, String deviceName, String time, String date){
        super();
        this.side=side;
        this.message = message;
        this.id=id.charAt(0)+""+id.charAt(1);
        this.deviceName=deviceName;
        this.time=time;
        this.date=date;
    }
}